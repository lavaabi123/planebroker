<?php

namespace App\Controllers;

use App\Database\Migrations\Users;
use App\Models\UsersModel;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */
class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;
    protected $userModel;
    protected $UsersModel;
    public $session; 
    public $segment; 
    public $db; 
    public $validation; 
    public $encrypter; 
    public $lang_base_url;
    public $selected_lang;
    public $general_settings;
    public $agent;
    public $analytics;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers     = ['cookie', 'date', 'security', 'form', 'menu', 'useraccess', 'custom'];

    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.
        $this->userModel      = new UsersModel();
        $this->session         = \Config\Services::session();
        $this->segment           = \Config\Services::request();
        $this->db             = \Config\Database::connect();
        $this->validation     = \Config\Services::validation();
        $this->encrypter     = \Config\Services::encrypter();
        register_CI4($this);
        //lang base url
        $this->lang_base_url = base_url();
        // selected_lang
        $this->selected_lang = selected_lang();
        $this->general_settings = get_general_settings();
        $this->agent = $this->request->getUserAgent();
        //update last seen
        $this->userModel->update_last_seen();
    }
}

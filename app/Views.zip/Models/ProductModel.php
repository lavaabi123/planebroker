<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'products';
    protected $primaryKey       = 'id';
    protected $allowedFields = ['status'];

    // Custom 
    protected $session;
    protected $request;

    public function __construct()
    {
        parent::__construct();
        $this->session = session();
        $this->request = \Config\Services::request();
    }
	
	public function get_filters($category = 'all', $where = '')
{
    // Get category details
	if($category == 'all'){
		
	}else{
    $category_detail = $this->db->query("
        SELECT id, name, skill_name, permalink 
        FROM categories 
        WHERE permalink LIKE '".$category."' 
        ORDER BY name ASC
    ", 'r')->getRowArray();
	}
    // Get field filters for that category
	$sql = "
        SELECT 
            id, 
            name, 
            filter_type, 
            LOWER(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(name, '/', '_'), ' ', '_'), '-', '_'), '(', '_'), ')', '_'), '&', '_')) as slug 
        FROM fields f
        LEFT JOIN field_categories c ON c.field_id = f.id 
        WHERE f.is_filter = 1 ";		
	if($category == 'all'){		
	}else{
	$sql .= " AND c.category_id = ".$category_detail['id']."";
	}
	$sql .= " GROUP BY name ORDER BY f.filter_order ASC";
    $result = $this->db->query($sql)->getResultArray();
    $filters = [];

    // Clean the WHERE clause for subquery use (remove table aliases)
    $cleanWhere = trim($where);
    $cleanWhere = ltrim($cleanWhere, 'AND ');
    //$cleanWhere = str_replace(['p.', 's.'], '', $cleanWhere);

    if (!empty($result)) {
        foreach ($result as $filter) {
            $values = [];

            if ($filter['filter_type'] == 'checkbox') {
                // Fetch value + count for each checkbox filter
				$sql1 = "
                    SELECT 
                        pd.field_value AS name, 
                        pd.field_id AS id, 
                        COUNT(DISTINCT pd.product_id) AS count 
                    FROM products_dynamic_fields pd
					LEFT JOIN products p on p.id=pd.product_id
					LEFT JOIN sales s on s.id=p.sale_id
                    WHERE pd.field_id IN (
                        SELECT id 
                        FROM fields 
                        WHERE name = '".$filter['name']."'
                    ) 
                    AND pd.product_id IN (
                        SELECT id 
                        FROM products ";
						if($category == 'all'){		
				}else{
                $sql1 .= "        WHERE category_id = ".$category_detail['id'].($cleanWhere ? " AND ".$cleanWhere : "")."";
				}
                $sql1 .= "    ) AND pd.field_value != ''
                    GROUP BY field_value
                ";
                $values = $this->db->query($sql1)->getResultArray();
            }

            // Add filter values to the response
			if(!empty($values)){
            $filter['values'] = $values;
            $filters[] = $filter;
			}
        }
    }

    return $filters;
}


	
    public function productPaginate()
{
    $request = service('request');
    $show = $request->getGet('show') ?? 25;

    $builder = $this->db->table('products p');
    $builder->select("
        p.*, 
        pl.is_premium_listing,pl.name as package_names,
        u.fullname,
        c.name as category_name,
        sc.name as sub_category_name,
        c.permalink,s.admin_plan_update,
        (
            SELECT GROUP_CONCAT(pd.field_value ORDER BY t.sort_order SEPARATOR ' ') 
            FROM products_dynamic_fields pd 
            JOIN (
                SELECT t.field_id, t.sort_order 
                FROM title_fields t 
                LEFT JOIN fields f ON f.id = t.field_id 
                WHERE t.title_type = 'title'
            ) t ON t.field_id = pd.field_id 
            WHERE pd.product_id = p.id
        ) as display_name,
        (
            SELECT field_value 
            FROM products_dynamic_fields 
            WHERE product_id = p.id 
            AND field_id = (
                SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'price' and fc.category_id=p.category_id LIMIT 1
            ) 
            LIMIT 1
        ) as price
    ");
    $builder->join('categories c', 'c.id = p.category_id', 'left');
    $builder->join('categories_sub sc', 'sc.id = p.sub_category_id', 'left');
    $builder->join('users u', 'u.id = p.user_id', 'left');
    $builder->join('plans pl', 'pl.id = p.plan_id', 'left');
    $builder->join('sales s', 's.id = p.sale_id', 'left');

    if (!empty($where)) {
        $builder->where($where); // ensure $where is an associative array or valid condition
    }
	
	$status = trim($request->getGet('status') ?? '');
	if ($status != null && ($status == 1 || $status == 0)) {
		$builder->where('p.status', clean_number($status));
	}
	
	$is_cancel = trim($request->getGet('is_cancel') ?? '');
	if ($is_cancel != null && ($is_cancel == 1 || $is_cancel == 0)) {
		$builder->where('p.is_cancel', clean_number($is_cancel));
	}
	
	$plan_id = trim($request->getGet('plan_id') ?? '');
	if ($plan_id != null && $plan_id > 0) {
		$builder->where('p.plan_id', clean_number($plan_id));
	}
	
	$user_id = trim($request->getGet('user_id') ?? '');
	if ($user_id != null && $user_id > 0) {
		$builder->where('p.user_id', clean_number($user_id));
	}
	
	$created_at_start = trim($request->getGet('created_at_start') ?? '');
	$created_at_end = trim($request->getGet('created_at_end') ?? '');
	if ($created_at_start != null && $created_at_end != null && ($created_at_start != '' && $created_at_end != '')) {
		$builder->where("DATE(p.created_at) >=", $created_at_start)
				->where("DATE(p.created_at) <=", $created_at_end);
	}
	$builder->orderBy('p.id','DESC');
    $pager = \Config\Services::pager();
    $result = $builder->get()->getResultArray(); // You cannot paginate here directly

    // Manual Pagination (less flexible):
    $page = (int) $request->getGet('page') ?? 1;
    $offset = ($page - 1) * $show;
    $total = count($result);
    $pagedData = array_slice($result, $offset, $show);
    return [
        'users'       => $pagedData,
        'pager' => $pager,
        'per_page_no' => $show,
        'total'       => $total
    ];
	
}


	
    public function product_lists()
{
    
    $builder = $this->db->table('products p');
    $builder->select("
        p.*, 
        pl.is_premium_listing,pl.name as package_names,
        u.fullname,
        c.name as category_name,
        sc.name as sub_category_name,s.id as original_sale_id,s.stripe_subscription_end_date,s.admin_plan_update,s.stripe_subscription_status,
        c.permalink,s.admin_plan_update,
        (
            SELECT GROUP_CONCAT(pd.field_value ORDER BY t.sort_order SEPARATOR ' ') 
            FROM products_dynamic_fields pd 
            JOIN (
                SELECT t.field_id, t.sort_order 
                FROM title_fields t 
                LEFT JOIN fields f ON f.id = t.field_id 
                WHERE t.title_type = 'title'
            ) t ON t.field_id = pd.field_id 
            WHERE pd.product_id = p.id
        ) as display_name,
        (
            SELECT field_value 
            FROM products_dynamic_fields 
            WHERE product_id = p.id 
            AND field_id = (
                SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'price' and fc.category_id=p.category_id LIMIT 1
            ) 
            LIMIT 1
        ) as price
    ");
    $builder->join('categories c', 'c.id = p.category_id', 'left');
    $builder->join('categories_sub sc', 'sc.id = p.sub_category_id', 'left');
    $builder->join('users u', 'u.id = p.user_id', 'left');
    $builder->join('plans pl', 'pl.id = p.plan_id', 'left');
    $builder->join('sales s', 's.id = p.sale_id', 'left');

	
	$builder->orderBy('p.id','DESC');
    return $result = $builder->get()->getResultArray(); // You cannot paginate here directly

	
}
	public function get_products($category='all',$where='',$orderby='p.is_cancel ASC,p.status DESC,p.plan_id DESC'){
		
		if($category == 'all'){
			$products = $this->db->query("SELECT p.*,pl.is_premium_listing,pl.name as package_name,pl.price as package_price,u.fullname,u.address as user_address,c.name as category_name,sc.name as sub_category_name,c.permalink,s.id as original_sale_id,s.admin_plan_update,(SELECT GROUP_CONCAT(pd.field_value ORDER BY t.sort_order SEPARATOR ' ') AS field_values FROM products_dynamic_fields pd JOIN ( SELECT t.field_id, t.sort_order FROM title_fields t LEFT JOIN fields f ON f.id = t.field_id WHERE t.title_type = 'title') t ON t.field_id = pd.field_id WHERE pd.product_id = p.id) as display_name, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'price' and fc.category_id=p.category_id LIMIT 1)LIMIT 1) as price, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'Aircraft Status' and fc.category_id=p.category_id LIMIT 1)LIMIT 1) as aircraft_status, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT id FROM `fields` where name = 'Price Notes ex. OBO, FIRM, MAKE AN OFFER, etc.' LIMIT 1)LIMIT 1) as price_notes FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN categories_sub sc ON sc.id=p.sub_category_id LEFT JOIN users u ON u.id=p.user_id left join plans pl on pl.id = p.plan_id left join sales s on s.product_id=p.id  WHERE p.id > 0 and u.fullname is not null ".$where." order by ".$orderby." ")->getResultArray();
		}else{
			$category_detail = $this->db->query("SELECT id, name,skill_name,permalink FROM categories WHERE permalink LIKE '".$category."' ORDER BY name ASC", 'r')->getRowArray();
			$products = $this->db->query("SELECT p.*,pl.is_premium_listing,pl.name as package_name,pl.price as package_price,u.fullname,u.address as user_address,c.name as category_name,sc.name as sub_category_name,c.permalink,s.admin_plan_update,s.id as original_sale_id,(SELECT GROUP_CONCAT(pd.field_value ORDER BY t.sort_order SEPARATOR ' ') AS field_values FROM products_dynamic_fields pd JOIN ( SELECT t.field_id, t.sort_order FROM title_fields t LEFT JOIN fields f ON f.id = t.field_id WHERE t.category_id = ".$category_detail['id']." and t.title_type = 'title') t ON t.field_id = pd.field_id WHERE pd.product_id = p.id) as display_name, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'price' and fc.category_id=p.category_id LIMIT 1) LIMIT 1) as price,(SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'Aircraft Status' and fc.category_id=p.category_id LIMIT 1)LIMIT 1) as aircraft_status, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT id FROM `fields` where name = 'Price Notes ex. OBO, FIRM, MAKE AN OFFER, etc.' LIMIT 1)LIMIT 1) as price_notes FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN categories_sub sc ON sc.id=p.sub_category_id LEFT JOIN users u ON u.id=p.user_id left join plans pl on pl.id = p.plan_id left join sales s on s.product_id=p.id  WHERE p.category_id = ".$category_detail['id']." and u.fullname is not null ".$where." order by ".$orderby."")->getResultArray();
		}
		
		//echo $this->db->getLastQuery();exit;
		$providers = array();
		if(!empty($products)){
			foreach($products as $product){
				if($product['original_sale_id'] != NULL){
				$pic = $this->db->query("SELECT file_name FROM user_images WHERE product_id='".$product['id']."' AND is_saved=0 ORDER BY file_type,`order` ASC LIMIT 1", 'a')->getRowArray();
				 
				if(empty($pic['file_name'])){ 
					$pic['file_name'] = base_url().'/assets/frontend/images/user.png';
				}else{
					$pic['file_name'] = base_url().'/uploads/userimages/'.$product['user_id'].'/'.$pic['file_name'];
				}
				
				$providers[] = array(
					'image' => $pic['file_name'],
					'id' => $product['id'],
					'name' => $product['display_name'],
					'user_name' => $product['fullname'],					
					'business_name' => $product['business_name'],
					'price' => ($product['price'] != NULL) ? (float)preg_replace('/[^\d.]/', '', $product['price']) : 0,
					'cat_name' => $product['category_name'],
					'cat_id' => $product['category_id'],
					'sub_cat_name' => $product['sub_category_name'],
					'permalink' => $product['permalink'],
					'city' => $product['city'],
					'state_code' => $product['state'],
					'zipcode' => $product['zipcode'],
					'clean_url' => $product['clean_url'],
					'avatar' => '',
					'user_id' => $product['user_id'],
					'plan_id' => $product['plan_id'],
					'sale_id' => $product['sale_id'],
					'website' => $product['website'],
					'status' => $product['status'],
					'is_premium_listing' => $product['is_premium_listing'],
					'package_name' => $product['package_name'],
					'package_price' => $product['package_price'],
					'address' =>$product['address'],
					'user_address' =>$product['user_address'],
					'phone' =>$product['phone'],
					'is_cancel' =>$product['is_cancel'],
					'wishlist_added' => !empty($this->session->get('vr_sess_user_id')) ? $this->wishlist_check($this->session->get('vr_sess_user_id'),$product['id']) : 0,
					'aircraft_status' => check_aircraft_status($product['id']),
					'admin_plan_update' => $product['admin_plan_update'],
					'price_notes' => $product['price_notes']
				);
				}
			}
		}
			
		
		//echo "<pre>";print_r($providers);exit;
		return $providers;
	}
		
	public function wishlist_check($user_id,$product_id){
		$wishlist = $this->db->query('SELECT count(*) fav_count FROM `user_favorites` where user_id = '.$user_id.' AND product_id = "'.$product_id.'" ')->getRow();
		return !empty($wishlist->fav_count) ? $wishlist : 0;
		
	}
	
	public function get_manufacturers($category, $where = '', $all = 1)
{
    // Step 1: Fetch the JSON-encoded field_options for "manufacturer"
    $manufacturers = $this->db->query("
        SELECT field_options 
        FROM fields 
        WHERE id IN (
            SELECT f.id 
            FROM fields f 
            JOIN field_categories c ON f.id = c.field_id 
            WHERE f.name = 'manufacturer' 
              AND c.category_id IN (
                  SELECT id FROM categories WHERE permalink = ?
              )
        )
    ", [$category])->getResult();

    $man = [];

    if (!empty($manufacturers[0]->field_options)) {
        $options = json_decode($manufacturers[0]->field_options, true);

        // Clean WHERE clause for subquery use
        $cleanWhere = trim($where);
        $cleanWhere = ltrim($cleanWhere, 'AND ');
        //$cleanWhere = str_replace(['p.', 's.'], '', $cleanWhere);

        // Step 2: Get counts per manufacturer using one query
        $countResults = $this->db->query("
            SELECT 
                pdf.field_value, 
                COUNT(DISTINCT pdf.product_id) AS count
            FROM products_dynamic_fields pdf
            JOIN fields f ON f.id = pdf.field_id
            JOIN field_categories fc ON fc.field_id = f.id
			
			LEFT JOIN products p on p.id=pdf.product_id
			LEFT JOIN sales s on s.id=p.sale_id
			LEFT JOIN plans pl on pl.id=p.plan_id
					
            WHERE f.name = 'manufacturer'
              AND fc.category_id IN (
                  SELECT id FROM categories WHERE permalink = ?
              )
              AND pdf.product_id IN (
                  SELECT id FROM products 
                  WHERE category_id IN (
                      SELECT id FROM categories WHERE permalink = ?
                  )
                  ".($cleanWhere ? " AND $cleanWhere" : "")."
              ) AND pdf.field_value != ''
            GROUP BY pdf.field_value
        ", [$category, $category])->getResult();

        // Map counts to manufacturer names
        $count_map = [];
        foreach ($countResults as $row) {
            $count_map[$row->field_value] = $row->count;
        }

        // Step 3: Return all options with their corresponding counts
        foreach ($options as $name) {
			if($all == 1 || ($all == 0 && !empty($count_map[$name])) ){
				$man[] = [
					'name'  => $name,
					'count' => $count_map[$name] ?? 0
				];
			}
        }
    }
	
    return json_decode(json_encode($man)); // optional: return as object
}


	
	public function get_models($category, $where = '')
{
    // Step 1: Get the field_options for "Make/Model"
    $models = $this->db->query("
        SELECT field_options 
        FROM fields 
        WHERE id IN (
            SELECT f.id 
            FROM fields f 
            JOIN field_categories c ON f.id = c.field_id 
            WHERE f.name = 'Make/Model' 
              AND c.category_id IN (
                  SELECT id FROM categories WHERE permalink = ?
              )
        )
    ", [$category])->getResult();

    $model_list = [];

    if (!empty($models[0]->field_options)) {
        $options = json_decode($models[0]->field_options, true);

        // Step 2: Clean the WHERE clause for subquery use
        $cleanWhere = trim($where);
        $cleanWhere = ltrim($cleanWhere, 'AND ');
        //$cleanWhere = str_replace(['p.', 's.'], '', $cleanWhere);

        // Step 3: Count product occurrences for each model
        $countResults = $this->db->query("
            SELECT 
                pdf.field_value, 
                COUNT(DISTINCT pdf.product_id) AS count
            FROM products_dynamic_fields pdf
            JOIN fields f ON f.id = pdf.field_id
            JOIN field_categories fc ON fc.field_id = f.id
			
			LEFT JOIN products p on p.id=pdf.product_id
			LEFT JOIN sales s on s.id=p.sale_id
			
            WHERE f.name = 'Make/Model'
              AND fc.category_id IN (
                  SELECT id FROM categories WHERE permalink = ?
              )
              AND pdf.product_id IN (
                  SELECT id FROM products 
                  WHERE category_id IN (
                      SELECT id FROM categories WHERE permalink = ?
                  )
                  ".($cleanWhere ? " AND $cleanWhere" : "")."
              ) AND pdf.field_value != ''
            GROUP BY pdf.field_value
        ", [$category, $category])->getResult();

        // Step 4: Map counts to each model name
        $count_map = [];
        foreach ($countResults as $row) {
            $count_map[$row->field_value] = $row->count;
        }

        // Step 5: Build final list with counts
        foreach ($options as $name) {
            $model_list[] = [
                'name'  => $name,
                'count' => $count_map[$name] ?? 0
            ];
        }
    }

    return json_decode(json_encode($model_list)); // optional: convert to object
}

		
	public function title_fields($category,$title_type = 'title',$productId=''){
		$category_detail = $this->db->query("SELECT id, name,skill_name,permalink FROM categories WHERE permalink LIKE '".$category."' ORDER BY name ASC", 'r')->getRowArray();
		if(!empty($productId)){
			$title_fields = $this->db->query("SELECT p.field_value as field_value, p.field_id as id, p.product_id,f.name as field_name FROM `products_dynamic_fields` p left join fields f on f.id = p.field_id where product_id = ".$productId." and p.field_id = (SELECT t.field_id FROM `title_fields` t left join fields f on f.id = t.field_id where t.category_id=".$category_detail['id']." and t.title_type ='".$title_type."')")->getRow();
		}else{
			$title_fields = $this->db->query("SELECT t.field_id,f.name FROM `title_fields` t left join fields f on f.id = t.field_id where t.category_id=".$category_detail['id']." and t.title_type = ".$title_type)->getResult();
		}
		
		return $title_fields;
	}
	
	public function get_product_dynamic_fields($category,$product_id){
		$category_detail = $this->db->query("SELECT id, name,skill_name,permalink FROM categories WHERE permalink LIKE '".$category."' ORDER BY name ASC", 'r')->getRowArray();
		$values = $this->db->query("
    SELECT 
        p.field_value AS name,
        p.field_id    AS id,
        p.file_field_title,
        p.product_id,
        f.name        AS field_name,
        fg.fields_group_id,
        g.name        AS group_name,
        f.field_type,
        f.frontend_show,
        pd.sub_category_id
    FROM products_dynamic_fields p
    LEFT JOIN fields f          ON f.id = p.field_id
    LEFT JOIN field_groups fg   ON fg.field_id = f.id
    LEFT JOIN fields_group g    ON g.id = fg.fields_group_id
    LEFT JOIN products pd       ON pd.id = p.product_id
    WHERE p.product_id = {$product_id}
      AND p.field_value <> ''
      AND NOT EXISTS (
            SELECT 1
            FROM title_fields t
            WHERE t.field_id   = p.field_id
              AND t.category_id = {$category_detail['id']}
              AND t.title_type  = 'description'
      )
      AND (
           COALESCE(f.show_cat_based,0) <> 1
           OR EXISTS (
                SELECT 1
                FROM field_sub_categories fs
                WHERE fs.field_id = f.id
                  AND fs.sub_category_id = pd.sub_category_id
           )
      )
    GROUP BY f.id, p.field_value
    ORDER BY g.sort_order, f.field_order
")->getResultArray();

		$fields = array();
		if(!empty($values)){
			foreach($values as $value){
				if($value['field_name'] == 'Price'){
					$value['name'] = ($value['name'] != NULL) ? 'USD $'.number_format((float)preg_replace('/[^\d.]/', '', $value['name']), 2, '.', ',') : 0;
				}
				$fields[$value['group_name']][] = $value;				
			}
		}
		return $fields;
	}
	
	public function delete_product($id)
    {
        return $this->delete($id);
    }
	public function product_status_change($id,$status){
		return $this->delete($id);
	}
	
	
	public function get_product_detail($where=''){		
		
		$product_detail = $this->db->query("SELECT p.*,u.fullname,c.name as category_name,sc.name as sub_category_name,c.permalink,(SELECT GROUP_CONCAT(pd.field_value ORDER BY t.sort_order SEPARATOR ' ') AS field_values FROM products_dynamic_fields pd JOIN ( SELECT t.field_id, t.sort_order FROM title_fields t LEFT JOIN fields f ON f.id = t.field_id WHERE t.title_type = 'title') t ON t.field_id = pd.field_id WHERE pd.product_id = p.id) as display_name, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT fi.id FROM `fields` fi  join field_categories fc on fc.field_id=fi.id where fi.name = 'price' and fc.category_id=p.category_id LIMIT 1)  limit 1) as price, (SELECT field_value FROM `products_dynamic_fields` where product_id = p.id and field_id = (SELECT id FROM `fields` where name = 'Price Notes ex. OBO, FIRM, MAKE AN OFFER, etc.' limit 1)  limit 1) as price_notes FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN categories_sub sc ON sc.id=p.sub_category_id LEFT JOIN users u ON u.id=p.user_id WHERE p.id >= 1 ".$where."")->getRowArray();
		
		// Safe normalization of price
		$rawPrice = $product_detail['price'] ?? null;
		$product_detail['price'] = is_string($rawPrice) && $rawPrice !== ''
			? (float) preg_replace('/[^\d.]/', '', $rawPrice)
			: 0.0;


		//$product_detail['price'] = ($product_detail['price'] != NULL) ? (float)preg_replace('/[^\d.]/', '', $product_detail['price']) : 0;
		
		return $product_detail;
	}
	
	public function check_fields($id){
		$product_detail = $this->db->query("SELECT NOT EXISTS (
  SELECT 1
  FROM products p
  JOIN fields f
    ON f.status = 1 AND f.field_condition = 1
  LEFT JOIN field_categories fc
    ON fc.field_id = f.id AND fc.category_id = p.category_id
  JOIN field_sub_categories fsc
    ON fsc.field_id = f.id AND fsc.sub_category_id = p.sub_category_id
  LEFT JOIN products_dynamic_fields pdf
    ON pdf.field_id = f.id AND pdf.product_id = p.id
  WHERE p.id = ".$id."
    AND (fc.field_id IS NOT NULL OR fsc.field_id IS NOT NULL)
    AND (pdf.field_value IS NULL OR TRIM(pdf.field_value) = '')
) AS all_required_fields_filled")->getRow();
		return $product_detail->all_required_fields_filled;
	}

public function get_recommended_products_guaranteed(int $currentProductId): array
{
    // ---------- helpers ----------
    $normPrice = fn($v)=> $v!==null ? (float)preg_replace('/[^\d.]/','',(string)$v) : 0.0;
    $normYear  = function($v){ $m=[]; return (preg_match('/\b(19|20)\d{2}\b/', (string)$v, $m) ? (int)$m[0] : null); };
    $extractAddr = function(string $addr){
        $zip=null;   if (preg_match('/\b\d{5}(?:-\d{4})?\b/',$addr,$m)) $zip=substr($m[0],0,5);
        $state=null; if (preg_match('/\b[A-Z]{2}\b/', strtoupper($addr), $m)) $state=$m[0];
        $city=null;  $parts=array_map('trim', explode(',',$addr)); if (!empty($parts[0]) && preg_match('/[A-Za-z]/',$parts[0])) $city=$parts[0];
        return [$zip,$state,$city];
    };

    // ---------- anchor ----------
    $anchor = $this->db->query("
        SELECT p.id, p.category_id, p.sub_category_id, p.address, p.created_at,
               (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='price' LIMIT 1) LIMIT 1) AS price_raw,
               (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Year'  LIMIT 1) LIMIT 1) AS year_raw,
               (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Make'  LIMIT 1) LIMIT 1) AS make_name,
               (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Model' LIMIT 1) LIMIT 1) AS model_name,
               (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Cabin Class' LIMIT 1) LIMIT 1) AS cabin_class
        FROM products p
        WHERE p.id = ? LIMIT 1
    ", [$currentProductId])->getRowArray();
    if (!$anchor) return [];

    $anchorPrice = $normPrice($anchor['price_raw'] ?? null);
    $anchorYear  = $normYear($anchor['year_raw'] ?? null);
    $priceMin = $anchorPrice ? $anchorPrice*0.75 : null;
    $priceMax = $anchorPrice ? $anchorPrice*1.25 : null;
    $yearMin  = $anchorYear ? $anchorYear-5 : null;
    $yearMax  = $anchorYear ? $anchorYear+5 : null;

    $makeTok  = strtolower((string)($anchor['make_name']  ?? ''));
    $modelTok = strtolower((string)($anchor['model_name'] ?? ''));
    $cabinTok = strtolower((string)($anchor['cabin_class']?? ''));
    $addrTok  = strtolower((string)($anchor['address']    ?? ''));
    [$aZip,$aState,$aCity] = $extractAddr($anchor['address'] ?? '');

    $avKeys = ['g1000','pro line 21','waas','ads-b','wi-fi','apu'];

    // Light family detection
    $familyTokens = [];
    foreach ([['7x','8x','falcon 7','falcon 8'], ['xls','xls+','citation xls'], ['sr22','sr22t']] as $group) {
        foreach ($group as $t) if ($modelTok && strpos($modelTok, $t)!==false) { $familyTokens = $group; break 2; }
    }
    if (!$familyTokens && $modelTok) $familyTokens = [$modelTok];

    // ---------- pool fetcher (STRICT CATEGORY + SALES JOIN) ----------
    $fetchPool = function(int $minPhotos, bool $excludePendingSold) use ($currentProductId, $anchor){
        $andPend = $excludePendingSold ? "
            AND NOT (
                LOWER(COALESCE(
                    (SELECT field_value FROM products_dynamic_fields
                       WHERE product_id = p.id AND field_id = (SELECT id FROM fields WHERE name='Aircraft Status' LIMIT 1)
                       LIMIT 1
                    ), ''
                )) LIKE '%pending%'
                OR
                LOWER(COALESCE(
                    (SELECT field_value FROM products_dynamic_fields
                       WHERE product_id = p.id AND field_id = (SELECT id FROM fields WHERE name='Aircraft Status' LIMIT 1)
                       LIMIT 1
                    ), ''
                )) LIKE '%sold%'
            )
        " : "";

        return $this->db->query("
            SELECT p.*, s.id AS sale_id,
                   u.fullname, c.name AS category_name, sc.name AS sub_category_name, c.permalink, p.address, p.created_at,
                   (SELECT GROUP_CONCAT(pd.field_value ORDER BY t.sort_order SEPARATOR ' ')
                      FROM products_dynamic_fields pd
                      JOIN (SELECT t.field_id, t.sort_order FROM title_fields t LEFT JOIN fields f ON f.id=t.field_id WHERE t.title_type='title') t
                        ON t.field_id=pd.field_id
                     WHERE pd.product_id=p.id
                   ) AS display_name,
                   (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='price' LIMIT 1) LIMIT 1) AS price_raw,
                   (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Year'  LIMIT 1) LIMIT 1) AS year_raw,
                   (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Make'  LIMIT 1) LIMIT 1) AS make_name,
                   (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Model' LIMIT 1) LIMIT 1) AS model_name,
                   (SELECT field_value FROM products_dynamic_fields WHERE product_id=p.id AND field_id=(SELECT id FROM fields WHERE name='Cabin Class' LIMIT 1) LIMIT 1) AS cabin_class,
                   (SELECT GROUP_CONCAT(pd2.field_value SEPARATOR ' ')
                      FROM products_dynamic_fields pd2
                     WHERE pd2.product_id=p.id
                       AND pd2.field_id IN (SELECT id FROM fields WHERE name IN ('Avionics','Avionics/Features','Equipment','Options'))
                   ) AS avionics_blob,
                   (SELECT COUNT(*) FROM user_images ui WHERE ui.product_id=p.id AND ui.is_saved=0) AS photo_count
            FROM products p
            INNER JOIN sales s ON s.id = p.sale_id
            LEFT JOIN categories c   ON c.id = p.category_id
            LEFT JOIN categories_sub sc ON sc.id = p.sub_category_id
            LEFT JOIN users u        ON u.id = p.user_id
            WHERE p.id <> ?
              AND p.status = 1
              AND p.category_id = ?
              AND (SELECT COUNT(*) FROM user_images ui WHERE ui.product_id=p.id AND ui.is_saved=0) >= ?
              $andPend
            ORDER BY p.created_at DESC
            LIMIT 500
        ", [$currentProductId, (int)$anchor['category_id'], $minPhotos])->getResultArray();
    };

    // ---------- scorer ----------
    $scoreOne = function(array $c) use ($normPrice,$normYear,$priceMin,$priceMax,$yearMin,$yearMax,$makeTok,$familyTokens,$cabinTok,$addrTok,$aZip,$aState,$aCity,$avKeys,$anchor,$extractAddr){
        $score = 0;
        $candPrice = $normPrice($c['price_raw'] ?? null);
        $candYear  = $normYear($c['year_raw'] ?? null);
        $candMake  = strtolower((string)($c['make_name']  ?? ''));
        $candModel = strtolower((string)($c['model_name'] ?? ''));
        $candCabin = strtolower((string)($c['cabin_class']?? ''));
        $candAddr  = strtolower((string)($c['address']    ?? ''));
        [$cZip,$cState,$cCity] = $extractAddr($c['address'] ?? '');

        // 1) same class/cabin
        if ((int)$c['sub_category_id'] === (int)$anchor['sub_category_id']) $score += 10;
        if ($cabinTok && $candCabin === $cabinTok) $score += 4;

        // 2) make/model family
        if ($makeTok && strpos($candMake, $makeTok)!==false) $score += 4;
        if ($familyTokens) { foreach ($familyTokens as $tok) { if ($tok && strpos($candModel, $tok)!==false) { $score += 6; break; } } }

        // 3) price ±25%
        if ($priceMin && $candPrice >= $priceMin && $candPrice <= $priceMax) $score += 8;

        // 4) year ±5
        if ($yearMin && $candYear && $candYear >= $yearMin && $candYear <= $yearMax) $score += 8;

        // 5) address proximity (ZIP3 > city > state > substring)
        if ($aZip && $cZip && substr($aZip,0,3) === substr($cZip,0,3)) $score += 10;
        else if ($aCity && $cCity && strcasecmp($aCity,$cCity)===0)     $score += 6;
        else if ($aState && $cState && strcasecmp($aState,$cState)===0) $score += 4;
        else if ($addrTok && $candAddr && (strpos($candAddr,$addrTok)!==false || strpos($addrTok,$candAddr)!==false)) $score += 3;

        // 6) avionics overlap (max +6)
        if (!empty($c['avionics_blob'])) {
            $blob = ' '.strtolower($c['avionics_blob']).' ';
            $hits = 0; foreach ($avKeys as $k) { if (strpos($blob,$k)!==false) $hits++; }
            $score += min($hits,6);
        }

        return $score;
    };

    // ---------- Phase A: strict (≥10 photos, exclude pending/sold) ----------
    $picked = [];
    $poolA = $fetchPool(10, true);

    // score by reference to avoid undefined _score
    foreach ($poolA as &$c) {
        $c['_score'] = $scoreOne($c);
        $picked[$c['id']] = true;
    }
    unset($c);

    // safe sort (handles missing keys)
    usort($poolA, function($x,$y){
        $sx = $x['_score']    ?? 0;
        $sy = $y['_score']    ?? 0;
        $cx = $x['created_at']?? '';
        $cy = $y['created_at']?? '';
        return ($sy <=> $sx) ?: strcmp($cy, $cx);
    });

    $final = array_slice($poolA, 0, 10);

    // ---------- Phase B: relax photos to ≥1 (still exclude pending/sold) ----------
    if (count($final) < 10) {
        $poolB = $fetchPool(1, true);
        foreach ($poolB as $row) {
            if (isset($picked[$row['id']])) continue;
            $row['_score'] = $scoreOne($row);
            $picked[$row['id']] = true;
            $final[] = $row;
            if (count($final) === 10) break;
        }
    }

    // ---------- Phase C: allow pending/sold in pool (≥1 photo) ----------
    if (count($final) < 10) {
        $poolC = $fetchPool(1, false);
        foreach ($poolC as $row) {
            if (isset($picked[$row['id']])) continue;
            $row['_score'] = $scoreOne($row);
            $picked[$row['id']] = true;
            $final[] = $row;
            if (count($final) === 10) break;
        }
    }

    // final ordering & trim
    usort($final, function($x,$y){
        $sx = $x['_score']    ?? 0;
        $sy = $y['_score']    ?? 0;
        $cx = $x['created_at']?? '';
        $cy = $y['created_at']?? '';
        return ($sy <=> $sx) ?: strcmp($cy, $cx);
    });
    $final = array_slice($final, 0, 10);

    // ---------- Shape for Owl ----------
    $out = [];
    foreach ($final as $p) {
        $pic = $this->db->query("SELECT file_name FROM user_images WHERE product_id=? AND is_saved=0 ORDER BY file_type,`order` ASC LIMIT 1", [$p['id']])->getRowArray();
        $img = !empty($pic['file_name']) ? base_url('uploads/userimages/'.$p['user_id'].'/'.$pic['file_name']) : base_url('assets/frontend/images/user.png');
        $priceNum = ($p['price_raw'] ?? null) ? (float)preg_replace('/[^\d.]/','',$p['price_raw']) : 0;

        $out[] = [
            'id'           => $p['id'],
            'sale_id'      => $p['sale_id'], // guaranteed due to INNER JOIN
            'name'         => $p['display_name'],
            'image'        => $img,
            'price'        => $priceNum,
            'cat_name'     => $p['category_name'],
            'sub_cat_name' => $p['sub_category_name'],
            'permalink'    => $p['permalink'],
            'address'      => $p['address'],
            'match_score'  => $p['_score'] ?? 0,
            'created_at'   => $p['created_at'],
			'category_id'  => $p['category_id'],
        ];
    }
    return $out;
}


}

<ul class="nav nav-tabs" id="tab-form" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="menu-category-tab" data-toggle="tab" href="#menu-category" role="tab" aria-controls="menu-category" aria-selected="true"><?php echo trans('menu_category') ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="menu-tab" data-toggle="tab" href="#menu" role="tab" aria-controls="menu" aria-selected="false"><?php echo trans('menu') ?></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="submenu-tab" data-toggle="tab" href="#submenu" role="tab" aria-controls="submenu" aria-selected="false"><?php echo trans('submenu') ?></a>
    </li>
</ul>
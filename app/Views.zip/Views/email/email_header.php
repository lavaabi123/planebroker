<!DOCTYPE html>
<html>
<body>
<style>
.main{
	margin:0 auto;
}
</style>
<table width="537px" cellpadding="0" cellspacing="0" align="center" style="background: #ffffff;font-family: 'Arial', Sans-serif; color:#07163a; font-size: 13px;">
	<thead>
		<tr>
			<th>
				<img src="<?php echo base_url(); ?>/assets/img/email_images/header.jpg">
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td style="text-align: center;padding:10px 10px 30px;">
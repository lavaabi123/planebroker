/**
 * Theme: Reactmore Admin
 * Author: More
 */

$(document).ready(function () {
    $('#wait').hide();
    $('#form').parsley();
    $("form").on('submit', function () {
        $("#crsf").attr("name", csrfName).val($.cookie(csrfCookie));
    });

    $(document).on('click', 'button[name="validate"]', function () {
        $(':required:invalid', '#form').each(function () {
            var id = $('.tab-pane').find(':required:invalid').closest('.tab-pane').attr('id');

            $('.nav a[href="#' + id + '"]').tab('show');
        });
    });


    $("#checkAll").on('click', function () {
        $('input:checkbox').not(this).prop('checked', this.checked);
    });

    $('.btnNext').click(function () {
        $('.nav-tabs .active').parent().next('li').find('a').trigger('click');
    });

    $('.btnPrevious').click(function () {
        $('.nav-tabs .active').parent().prev('li').find('a').trigger('click');
    });

    $('.menu_category_permission').on('click', function () {
        const menuCategoryId = $(this).data('menucategory');
        const roleId = $(this).data('role');
        var data = {
            'menuCategoryID': menuCategoryId,
            'roleID': roleId,
        };
        data[csrfName] = $.cookie(csrfCookie);

        $.ajax({
            url: baseUrl + "/admin/role-management/change-menu-category-permission",

            type: 'post',
            data: data,
            success: function () {
                // alert('User Access has been changed !');
                location.reload();
            }
        });
    });

    $('.menu_permission').on('click', function () {
        const menuId = $(this).data('menu');
        const roleId = $(this).data('role');

        var data = {
            'menuID': menuId,
            'roleID': roleId,
        };

        data[csrfName] = $.cookie(csrfCookie);

        $.ajax({
            url: baseUrl + "/admin/role-management/change-menu-permission",
            type: 'post',
            data: data,
            success: function (response) {
                console.log(response);
                // alert('User Access has been changed !');
                location.reload();
            }
        });
    });

    $('.submenu_permission').on('click', function () {
        const submenuID = $(this).data('submenu');
        const roleId = $(this).data('role');

        var data = {
            'submenuID': submenuID,
            'roleID': roleId,
        };
        data[csrfName] = $.cookie(csrfCookie);

        $.ajax({
            url: baseUrl + "/admin/role-management/change-submenu-permission",
            type: 'post',
            data: data,
            success: function () {
                // alert('User Access has been changed !');
                location.reload();
            }
        });
    });

    document.querySelectorAll('[data-toggle="password"]').forEach(function (el) {
        el.addEventListener("click", function (e) {
            e.preventDefault();

            var target = el.dataset.target;
            var icon = el.dataset.icon;
            document.querySelector(target).focus();
            document.querySelector(icon).focus();

            if (document.querySelector(target).getAttribute('type') == 'password') {
                document.querySelector(target).setAttribute('type', 'text');
                document.querySelector(icon).setAttribute('class', 'fa fa-eye-slash');
            } else {
                document.querySelector(target).setAttribute('type', 'password');
                document.querySelector(icon).setAttribute('class', 'fa fa-eye');
            }
        });
    });
});




function generateUniqueString(prefix) {
    var time = String(new Date().getTime()),
        i = 0,
        output = '';
    for (i = 0; i < time.length; i += 2) {
        output += Number(time.substr(i, 2)).toString(36);
    }
    return (prefix + '-' + output.toUpperCase());
}

function custom_alert(type, msg, reload = true) {
    var toastMixin = Swal.mixin({
        toast: true,
        icon: type,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,

        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer);
            toast.addEventListener('mouseleave', Swal.resumeTimer);
            toast.addEventListener('click', Swal.close);
        },
        didClose: () => {
            if (reload) {
                location.reload();
            }
        }


    });

    toastMixin.fire({
        title: msg
    });
};


//confirm user email
function confirm_user_email(id) {
    var data = {
        'id': id,
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: `${baseUrl}/admin/providers/confirm_user_email`,
        data: data,
        success: function (response) {
            location.reload();
        }
    });
};

//delete item
function delete_item(url, id, message) {
    Swal.fire({
        text: message,
        icon: "warning",
        showCancelButton: 1,
        confirmButtonColor: "#34c38f",
        cancelButtonColor: "#f46a6a",
        confirmButtonText: sweetalert_ok,
        cancelButtonText: sweetalert_cancel,
    }).then(function (willDelete) {
        if (willDelete.value) {
            var data = {
                'id': id,
            };
            data[csrfName] = $.cookie(csrfCookie);
            $.ajax({
                type: "POST",
                url: baseUrl + url,
                data: data,
                beforeSend: function () {
                    $("#wait").show();
                },
                complete: function () {
                    $("#wait").hide();

                },
                success: function (response) {
                    location.reload();
                }
            });
        }
    });
};

//ban user
function ban_user(id, message, option) {
    Swal.fire({
        text: message,
        icon: "warning",
        showCancelButton: 1,
        confirmButtonColor: "#34c38f",
        cancelButtonColor: "#f46a6a",
        confirmButtonText: sweetalert_ok,
        cancelButtonText: sweetalert_cancel,

    }).then(function (willDelete) {
        if (willDelete.value) {
            var data = {
                'id': id,
                'option': option
            };
            const newLocal = $.cookie(csrfCookie);
            data[csrfName] = newLocal;
            $.ajax({
                type: "POST",
                url: `${baseUrl}/admin/providers/ban_user_post`,
                data: data,
                beforeSend: function () {
                    $("#wait").show();
                },
                complete: function () {
                    $("#wait").hide();

                },
                success: function (response) {
                    location.reload();
                }
            });
        }
    });
};

function get_states_by_county(val) {
    var data = {
        "county_id": val
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/get_states_by_county",
        data: data,
        success: function (response) {
            var obj = JSON.parse(response);
            if (obj.result == 1) {
                document.getElementById("selected_states").innerHTML = obj.content;
            }
        }
    });
}

function get_states(val, map) {
    $('#select_states').children('option').remove();
    $('#select_cities').children('option').remove();
    $('#get_states_container').hide();
    $('#get_cities_container').hide();
    var data = {
        "county_id": val,
        "sys_lang_id": sys_lang_id
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/get_states",
        data: data,
        success: function (response) {
            var obj = JSON.parse(response);
            if (obj.result == 1) {
                document.getElementById("select_states").innerHTML = obj.content;
                $('#get_states_container').show();
            } else {
                document.getElementById("select_states").innerHTML = "";
                $('#get_states_container').hide();
            }
            if (map) {
                update_product_map();
            }
        }
    });
}

function get_cities(val, map) {
    var data = {
        "state_id": val,
        "sys_lang_id": sys_lang_id
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/get_cities",
        data: data,
        success: function (response) {
            var obj = JSON.parse(response);
            if (obj.result == 1) {
                document.getElementById("select_cities").innerHTML = obj.content;
                $('#get_cities_container').show();
            } else {
                document.getElementById("select_cities").innerHTML = "";
                $('#get_cities_container').hide();
            }
            if (map) {
                update_product_map();
            }
        }
    });
}


function update_product_map() {
    var county_text = $("#select_counties").find('option:selected').text();
    var county_val = $("#select_counties").find('option:selected').val();
    var state_text = $("#select_states").find('option:selected').text();
    var state_val = $("#select_states").find('option:selected').val();
    var city_text = $("#select_cities").find('option:selected').text();
    var city_val = $("#select_cities").find('option:selected').val();
    var address = $("#address_input").val();
    var zip_code = $("#zip_code_input").val();
    var data = {
        "county_text": county_text,
        "county_val": county_val,
        "state_text": state_text,
        "state_val": state_val,
        "city_text": city_text,
        "city_val": city_val,
        "address": address,
        "zip_code": zip_code,
        "sys_lang_id": sys_lang_id
    };


    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/show_address_on_map",
        data: data,
        success: function (response) {

            document.getElementById("map-result").innerHTML = response;
        }
    });
}

//activate inactivate counties
function activate_inactivate_counties(action) {
    var data = {
        "action": action
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/admin/locations/county/activate-inactivate-counties",
        data: data,
        success: function (response) {
            location.reload();
        }
    });
};


function get_provider_messages(message_id) {
    var data = {
        "message_id": message_id
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/get_provider_messages",
        data: data,
        success: function (data) {
            $('#provider-message-content').html(data);
            $('#modal-provider-message').modal('show');
        }
    });
}

function delete_provider_messages(message_id) {
    var data = {
        "message_id": message_id
    };
	Swal.fire({
        text: 'Do you want to delete this message?',
        icon: "info",
        showCancelButton: 1,
        confirmButtonColor: "#34c38f",
        cancelButtonColor: "#f46a6a",
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
    }).then(function (willDelete) {
        if (willDelete.value) {            
			//data[csrfName] = $.cookie(csrfCookie);
			$.ajax({
				type: "POST",
				url: baseUrl + "/common/delete_provider_messages",
				data: data,
				success: function (data) {
					$('#provider-message-content').html(data);
					$('#pm'+message_id).hide();
				}
			});
        }
    });
}

function get_contact_messages(message_id) {
    var data = {
        "message_id": message_id
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/get_contact_messages",
        data: data,
        success: function (data) {
            $('#provider-message-content').html(data);
            $('#modal-provider-message').modal('show');
        }
    });
}

function get_captain_messages(message_id) {
    var data = {
        "message_id": message_id
    };
    data[csrfName] = $.cookie(csrfCookie);
    $.ajax({
        type: "POST",
        url: baseUrl + "/common/get_captain_messages",
        data: data,
        success: function (data) {
            $('#provider-message-content').html(data);
            $('#modal-provider-message').modal('show');
        }
    });
}